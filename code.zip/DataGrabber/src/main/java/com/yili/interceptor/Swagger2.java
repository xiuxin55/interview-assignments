package com.yili.interceptor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.collect.Lists;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@ConditionalOnProperty(name = "swagger.enable", havingValue = "true")
public class Swagger2 {

    @Value("${spring.application.name:}")
    String applicationName;

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    @Bean
    public Docket createRestApi() {
        // ==================== 需要的参数 START ====================
        List<Parameter> pars = new ArrayList<>();
        ParameterBuilder token = new ParameterBuilder();
        token.name("x-token").description("token类型").modelRef(new ModelRef("string"))
            .parameterType("header").required(false).build();
        pars.add(token.build());
        return new Docket(DocumentationType.SWAGGER_2)// .globalOperationParameters(pars)//全局参数
            .select()
            // 方法需要有ApiOperation注解才能生存接口文档
            .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
            // 路径使用any风格
            .paths(PathSelectors.any()).build().globalOperationParameters(pars)
            // 如何保护我们的Api，有三种验证（ApiKey, BasicAuth, OAuth）
            .securityContexts(securityContexts()).securitySchemes(security())
            // 接口文档的基本信息
            .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("短域名-" + applicationName + "-api文档").description("接口文档")
            .version("1.0").build();
    }

    private List<ApiKey> security() {

        return Lists.newArrayList(new ApiKey("Authorization", "Authorization", "header"));
    }

    private List<SecurityContext> securityContexts() {

        SecurityContext context = SecurityContext.builder().securityReferences(defaultAuth())
            //.forPaths(PathSelectors.regex("^(?!auth).*$"))
            .build();

        return Lists.newArrayList(context);

    }

    private List<SecurityReference> defaultAuth() {

        AuthorizationScope authorizationScope =
            new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;

        return Lists.newArrayList(new SecurityReference("Authorization", authorizationScopes));

    }

}