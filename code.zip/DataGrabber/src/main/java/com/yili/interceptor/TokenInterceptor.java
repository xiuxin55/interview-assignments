package com.yili.interceptor;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.yili.bean.ResultBase;
import com.yili.utils.Constants;


public class TokenInterceptor implements HandlerInterceptor {
	private Logger log = LoggerFactory.getLogger(TokenInterceptor.class);
//	@Autowired
//	private TblDgUserDAO userMapper;

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String origin = request.getHeader("Origin");
		String ip = getIp(request);
		log.info("IP:" + ip);
		if (origin == null || origin.equals("")) {
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Methods", "*");
			response.setHeader("Access-Control-Allow-Headers", "*");
		} else {
			response.setHeader("Access-Control-Allow-Origin", origin);
			response.setHeader("Access-Control-Allow-Methods", "*");
			response.setHeader("Access-Control-Allow-Headers", "authorization,content-type,x-token");
		}
		String requestUri2 = request.getRequestURI();
		// get请求不拦截
		String method = request.getMethod();
		if (method != null && !method.toLowerCase().equals("post")) {
			return true;
		}

//		String requestUri = request.getRequestURI();
//		if (requestUri.endsWith("user/login")) {
//			return true;
//		}
//
//		String token = request.getHeader("Authorization");
//		if (token != null && token.length() > 0) {
//
//		} else {
//			returnErrorMessage(response, "非法请求,请登录");
//			return false;
//		}
		return true;
	}

	private String getIp(HttpServletRequest request) {

		String ip = request.getHeader("HTTP_X_FORWARDED_FOR");

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("x-forwarded-for");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {

			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknow".equalsIgnoreCase(ip)) {

			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {

			ip = request.getHeader("HTTP_CLIENT_IP");
		}

		return ip;
	}

	private void returnErrorMessage(HttpServletResponse response, String errorMessage) {

		PrintWriter out = null;
		try {
			ResultBase rst = new ResultBase();
			rst.setCode(-1);
			rst.setMessage(errorMessage);
			response.setContentType("application/json");
			response.setCharacterEncoding(Constants.ENCODING);
			out = response.getWriter();
			out.print(JSONObject.toJSONString(rst));
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

}
