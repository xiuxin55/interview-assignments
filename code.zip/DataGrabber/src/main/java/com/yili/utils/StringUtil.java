package com.yili.utils;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.yili.utils.EnumUtil.DataTypeEnum;

public class StringUtil {

	public static Boolean checkIsNull(Class<?> type, Object obj) {
		// if(obj==null)
		// {
		// return true;
		// }
		// try {
		// java.lang.reflect.Field[] fields = type.getDeclaredFields();
		// for (int i = 0; i < fields.length; i++) {
		// java.lang.reflect.Field item=fields[i];
		// FieldNameAnnotation anno = item.getAnnotation(FieldNameAnnotation.class);
		// item.setAccessible(true);
		// Object result= item.get(obj);
		// if(anno!=null)
		// {
		// if(result!=null&& result.toString().length()>0)
		// {
		// return false;
		// }
		// }
		// }
		// return true;
		// } catch (Exception e) {
		//
		// }
		return false;
	}

	// 生成随机数字和字母,
	public static String getStringRandom(int length) {

		String val = "";
		Random random = new Random();
		// length为几位密码
		for (int i = 0; i < length; i++) {
			String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
			// 输出字母还是数字
			if ("char".equalsIgnoreCase(charOrNum)) {
				// 输出是大写字母还是小写字母
				int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
				val += (char) (random.nextInt(26) + temp);
			} else if ("num".equalsIgnoreCase(charOrNum)) {
				val += String.valueOf(random.nextInt(10));
			}
		}
		return val;
	}

	/**
	 * 获取字符串默认值
	 */
	public static Object defaultValue(int type) {

		String result = "";
		if (type == DataTypeEnum.INTEGER.getIndex()) {
			result = "0";
		} else if (type == DataTypeEnum.BOOLEAN.getIndex()) {
			result = "true";
		} else if (type == DataTypeEnum.DATE.getIndex()) {
			result = "1990-01-01";
		} else if (type == DataTypeEnum.DOUBLE.getIndex()) {
			result = "0.0";
		}
		return getDataToObject(result);
	}

	/**
	 * 获取字符串默认值
	 */
	public static Object defaultValueForm(int type) {

		String result = "";
		if (type == DataTypeEnum.INTEGER.getIndex()) {
			result = "1";
		} else if (type == DataTypeEnum.BOOLEAN.getIndex()) {
			result = "true";
		} else if (type == DataTypeEnum.DATE.getIndex()) {
			result = "1990-01-01";
		} else if (type == DataTypeEnum.DOUBLE.getIndex()) {
			result = "1.1";
		}
		return getDataToObject(result);
	}

	/**
	 * 获取字符串数据类型
	 * 
	 */
	public static Integer getDataType(String str) {
		Integer result = DataTypeEnum.CHARACTER.getIndex();

		if (isInteger(str)) {
			result = DataTypeEnum.INTEGER.getIndex();
		} else if (isBoolean(str)) {
			result = DataTypeEnum.BOOLEAN.getIndex();
		} else if (isDate(str)) {
			result = DataTypeEnum.DATE.getIndex();
		} else if (isDouble(str)) {
			result = DataTypeEnum.DOUBLE.getIndex();
		}
		return result;
	}

	/**
	 * 获取字符串数据类型
	 * 
	 */
	public static Object getDataToObject(String str) {
		Object result = str;
		if (isInteger(str)) {
			result = Long.valueOf(str);
		} else if (isBoolean(str)) {
			result = Boolean.valueOf(str);
		} else if (isDate(str)) {
			result = stringFormtDate(str);
		} else if (isDouble(str)) {
			result = Double.valueOf(str);
		}
		return result;
	}

	private static boolean isBoolean(String str) {
		if (null == str || "".equals(str)) {
			return false;
		}
		if ("true".equals(str.toLowerCase()) || "false".equals(str.toLowerCase())) {
			return true;
		}
		return false;
	}

	// 判断整数（int）
	public static boolean isInteger(String str) {
		if (null == str || "".equals(str) || str.length() > 10) {
			return false;
		}
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	// 判断浮点数（double和float）
	public static boolean isDouble(String str) {
		if (null == str || "".equals(str)) {
			return false;
		}
		try {
			NumberFormat nf = NumberFormat.getInstance();
			nf.setGroupingUsed(false);
			Double tqd = new Double(str);
			str = String.valueOf(nf.format(tqd));
		} catch (Exception ex) {
		}

		try {
			Double.valueOf(str);
			return true;

		} catch (Exception ex) {
			return false;
		}

		/*
		 * Pattern pattern = Pattern.compile("^[-\\+]?[.\\d]*$");
		 * 
		 * return pattern.matcher(str).matches();
		 */
	}

	/**
	 * 是否是日期格式
	 */
	private static boolean isDate(String str) {

		if (null == str || "".equals(str)) {
			return false;
		}
		String dateStr = "";
		String timeStr = "";
		String[] arr = str.split(" ");
		if (arr.length == 2) {
			String dateDIY = dateFormatDIY(arr[0]);
			if (dateDIY == null) {
				return false;
			} else {
				dateStr = dateDIY;
			}

			if (arr[1].length() == 5) {
				timeStr = arr[1] + ":00";
			} else if (arr[1].length() == 8) {
				timeStr = arr[1];
			} else {
				return false;
			}

		} else {
			String dateDIY = dateFormatDIY(arr[0]);
			if (dateDIY == null) {
				return false;
			} else {
				dateStr = dateDIY;
			}
			timeStr = "00:00:00";
		}

		str = dateStr + " " + timeStr;

		SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // 加上时间
		// 必须捕获异常
		try {
			Date date = sDateFormat.parse(str);
			return true;
		} catch (ParseException px) {
			return false;
		}

	}

	private static String dateFormatDIY(String str) {
		String result = null;
		if (str != null && !str.equals("") && str.length() > 5) {
			str = str.replace("/", "-");
			String[] dateArr = str.split("-");
			if (dateArr.length == 3) {
				if (dateArr[0].length() == 2) {
					result = "20" + dateArr[0];
				} else {
					result = dateArr[0];
				}
				if (dateArr[1].length() == 1) {
					result += "-0" + dateArr[1];
				} else {
					result += "-" + dateArr[1];
				}

				if (dateArr[2].length() == 1) {
					result += "-0" + dateArr[2];
				} else {
					result += "-" + dateArr[2];
				}
			} else if (dateArr.length == 2) {
				if (dateArr[0].length() == 2) {
					result = "20" + dateArr[0];
				} else {
					result = dateArr[0];
				}
				if (dateArr[1].length() == 1) {
					result += "-0" + dateArr[1];
				} else {
					result += "-" + dateArr[1];
				}
				result += "-01";
			}
		}

		return result;
	}

	/**
	 * 是否是日期格式
	 */
	public static String stringFormtDate(String str) {

		String dateStr = "1990-01-01";
		if (null != str && !"".equals(str)) {
			String[] arr = str.split(" ");
			if (arr.length == 2) {
				String dateDIY = dateFormatDIY(arr[0]);
				if (dateDIY != null) {
					dateStr = dateDIY;
				}
				if (arr[1].length() >= 5) {
					dateStr += " " + arr[1];
				}
			} else if (arr.length == 1) {
				String dateDIY = dateFormatDIY(arr[0]);
				if (dateDIY != null) {
					dateStr = dateDIY;
				}
			}
		}
		if (str.indexOf("/") > -1) {
			dateStr.replace("-", "/");
		}
		return dateStr;
	}

	public static Object[] sort(Object[] keys) {
		String temp = null;
		for (int i = 0; i < keys.length; i++) {
			for (int j = i + 1; j < keys.length; j++) {
				if (keys[i].toString().length() < keys[j].toString().length()) {
					temp = keys[i].toString();
					keys[i] = keys[j];
					keys[j] = temp;
				}
			}
		}
		return keys;
	}

	public static String getFormula(String str, Map<String, String> formulaMap) {
		Map<String, Integer> existMap = null;
		for (String key : formulaMap.keySet()) {
			if (str.indexOf(key) > -1) {
				existMap = new HashMap<String, Integer>();
				existMap.put(key, 1);
				str = str.replace(key, "(" + formulaMap.get(key) + ")");
				str = getFormulaLoop(str, formulaMap, existMap);
				return str;
			}
		}
		return str;
	}

	private static String getFormulaLoop(String str, Map<String, String> formulaMap, Map<String, Integer> existMap) {
		for (String key : formulaMap.keySet()) {
			if (str.indexOf(key) > -1) {
				Integer existCount = 1;
				if (existMap.containsKey(key)) {
					existCount = existMap.get(key);
					if (existCount > 200) {
						return null;
					}
					existMap.put(key, existCount + 1);
				} else {
					existMap.put(key, existCount);
				}
				str = str.replace(key, "(" + formulaMap.get(key) + ")");
				str = getFormulaLoop(str, formulaMap, existMap);
				if (str == null) {
					return str;
				}

			}
		}
		return str;

	}

	// 验证字段
	public static boolean verifyStr(String regex, String str) {
		boolean flag = true;
		if (regex != null && !regex.equals("")) {
			Pattern p = Pattern.compile(regex);

			Matcher m = p.matcher(str);

			if (!m.matches()) {

				flag = false;

			}
		}
		return flag;
	}

	// 是否英文
	public static boolean isEnglish(String charaString) {

		return charaString.matches("^[a-zA-Z]*");

	}

	/**
	 * 检查字符串是否数字
	 * 
	 * @param str
	 * @return
	 */
	public static boolean checkStrIsNum01(String str) {
		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
