package com.yili.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * tbl_dg_log
 * @author 
 */
public class TblDgLog implements Serializable {
    /**
     * ID
     */
    private Integer id;

    /**
     * 描述
     */
    private String content;

    /**
     * 1:政策动见;2:数说经济;3:行业新闻;4:创新周报;5:公司动态
     */
    private Integer logType;

    /**
     * 子类型
     */
    private Integer logTypeSub;

    /**
     * 1:操作成功；-1操作失败
     */
    private Integer logSuccess;

    /**
     * 抓取地址
     */
    private String url;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 创建时间
     */
    private Date createDate;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getLogType() {
        return logType;
    }

    public void setLogType(Integer logType) {
        this.logType = logType;
    }

    public Integer getLogTypeSub() {
        return logTypeSub;
    }

    public void setLogTypeSub(Integer logTypeSub) {
        this.logTypeSub = logTypeSub;
    }

    public Integer getLogSuccess() {
        return logSuccess;
    }

    public void setLogSuccess(Integer logSuccess) {
        this.logSuccess = logSuccess;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        TblDgLog other = (TblDgLog) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getContent() == null ? other.getContent() == null : this.getContent().equals(other.getContent()))
            && (this.getLogType() == null ? other.getLogType() == null : this.getLogType().equals(other.getLogType()))
            && (this.getLogTypeSub() == null ? other.getLogTypeSub() == null : this.getLogTypeSub().equals(other.getLogTypeSub()))
            && (this.getLogSuccess() == null ? other.getLogSuccess() == null : this.getLogSuccess().equals(other.getLogSuccess()))
            && (this.getUrl() == null ? other.getUrl() == null : this.getUrl().equals(other.getUrl()))
            && (this.getUserName() == null ? other.getUserName() == null : this.getUserName().equals(other.getUserName()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getContent() == null) ? 0 : getContent().hashCode());
        result = prime * result + ((getLogType() == null) ? 0 : getLogType().hashCode());
        result = prime * result + ((getLogTypeSub() == null) ? 0 : getLogTypeSub().hashCode());
        result = prime * result + ((getLogSuccess() == null) ? 0 : getLogSuccess().hashCode());
        result = prime * result + ((getUrl() == null) ? 0 : getUrl().hashCode());
        result = prime * result + ((getUserName() == null) ? 0 : getUserName().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", content=").append(content);
        sb.append(", logType=").append(logType);
        sb.append(", logTypeSub=").append(logTypeSub);
        sb.append(", logSuccess=").append(logSuccess);
        sb.append(", url=").append(url);
        sb.append(", userName=").append(userName);
        sb.append(", createDate=").append(createDate);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}