package com.yili.bean;

public class ResultData<T> extends ResultBase {

	private T data;//

	private Integer totalCount;//

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

}
