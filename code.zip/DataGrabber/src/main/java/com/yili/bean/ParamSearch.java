package com.yili.bean;

import java.util.Date;

import io.swagger.annotations.ApiModel;
@ApiModel(description = "搜索参数模型")
public class ParamSearch {
	/**
	 * 页面码索引
	 */
	private Integer pageIndex;
	/**
	 * 页记录条数
	 * 
	 */
	private Integer pageSize = 10;

	/**
	 * URL地址
	 * 
	 */
	private String keyWord;
	/**
	 * 起始日期
	 * 
	 */
	private Date startDate;
	/**
	 * 结束日期
	 * 
	 */
	private Date endDate;
	/**
	 * 类型
	 * 
	 */
	private Integer type;

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}
}
