package com.yili.services;

import java.util.List;

import com.yili.bean.ParamSearch;
import com.yili.bean.ResultData;
import com.yili.entity.TblDgLog;

public interface IShortService {
	/**
	 * 分页查询
	 * 
	 * @param 条件
	 * @return 记录条数
	 */
	ResultData<String> getShortDomain(ParamSearch param);
	/**
	 * 返回真实域名
	 * 
	 * @key 条件
	 * @return 记录条数
	 */
	public ResultData<String> getDomainUrl(String key);
}
